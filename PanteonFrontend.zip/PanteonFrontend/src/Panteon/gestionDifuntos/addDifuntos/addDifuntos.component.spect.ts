import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { addDifuntosComponent } from './adddifuntos.component';

describe('addDifuntosComponent', () => {
  let component: addDifuntosComponent;
  let fixture: ComponentFixture<addDifuntosComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ addDifuntosComponent ]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(addDifuntosComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
