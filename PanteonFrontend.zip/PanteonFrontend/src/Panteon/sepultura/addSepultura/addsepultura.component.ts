import { Component, OnInit } from '@angular/core';
import {FormBuilder, FormGroup} from "@angular/forms";

@Component({
  selector: 'app-addsepulturas',
  templateUrl: './addsepulturas.component.html',
  styleUrls: ['./addsepulturas.component.scss']
})
export class addsepulturasComponent implements OnInit {
  sepulturaForm: FormGroup;

  constructor(private fb: FormBuilder) {
    this.sepulturaForm = this.fb.group({
      numeroDeSepultura:[''],
      numeroAntiguo:[''],
      ultimoDifunto:[''],
      fechadeDefuncion:[''],
      dni:[''],
      estado:[''],
      parentesco:[''],
      capacidad:[''],
      campoSanto:[''],
      sanMartin:[''],
      nogales:[''],
      rioBlanco:['']

    });
  }

  ngOnInit() {
  }

  onSave() {
    console.log('saving...');
    console.log(this.sepulturaForm.value);
  }
}
