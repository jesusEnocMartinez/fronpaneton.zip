import { Component, OnInit } from '@angular/core';
import {FormBuilder, FormGroup} from "@angular/forms";

@Component({
  selector: 'app-usuario',
  templateUrl: './usuario.component.html',
  styleUrls: ['./usuario.component.scss']
})
export class UsuarioComponent implements OnInit {
  usuarioForm: FormGroup
  constructor(private fb: FormBuilder) {
    this.usuarioForm = this.fb.group({
      nombre:[''],
      apellidos:[''],
      telefono:[''],
      correo:[''],
      usuario:[''],
      contraseña:[''],
      contraseña1:['']
    });


  }

  ngOnInit() {
  }

  onSave() {
    console.log('saving...');
    console.log(this.usuarioForm.value);
  }
}
