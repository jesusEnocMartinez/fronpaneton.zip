import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { addsepulturasComponent } from './addsepulturas.component';

describe('addsepulturasComponent', () => {
  let component: addsepulturasComponent;
  let fixture: ComponentFixture<addsepulturasComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ addsepulturasComponent ]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(addsepulturasComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
