import { Component, OnInit } from '@angular/core';
import {FormBuilder, FormGroup} from "@angular/forms";

@Component({
  selector: 'app-addDifuntos',
  templateUrl: './addDifuntos.component.html',
  styleUrls: ['./addDifuntos.component.scss']
})
export class addDifuntosComponent implements OnInit {
  addDifuntosForm: FormGroup;


  constructor(private fb: FormBuilder) {
    this.addDifuntosForm= this.fb.group( {
      dni: [''],
      nombreDifunto: [''],
      fechadeEnterrramiento: [''],
      fechadeDefuncion:[''],
      edadDefallicimiento:[''],
      estadoCivil:[''],
      localidad:[''],
      domicilio:[''],
      anotaciones:[''],
      numeroDeFicha:[''],
      numerodeHilera:[''],
      sujetoaOrdenJudicial:[''],
      si:[''],
      no:['']
    });

  }

  ngOnInit() {
  }

  onSave() {
    console.log('saving...');
    console.log(this.addDifuntosForm.value)
  }
}

